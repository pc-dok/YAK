#-------------------------------------------------------------------------------
# function Build md5 sum's
# $1 = pipe delimited list of file extensions to exclude, e.g. "exe|ps1|win|dll"
#-------------------------------------------------------------------------------
Md5Sum() {
  case ${ZIP_PRODUCT_NAME} in
    dmk|dmk_dbduplicate|dmk_ha) files='bin/* lib/*.p[lm] sql/*.sql' ;;
    dmk_dbbackup)               files='bin/* lib/*.p[lm]' ;;
    dmk_dbcreate)               files='bin/* sql/*.sql' ;;
    dmk_sql)                    files='bin/* pls/*.pls sql/*.sql' ;;
    *)                          files='bin/*' ;;
  esac
 # md5sum -b $files | grep -v -i -E "\.($1)$" > doc/filelist.md5

}

# Add Release Tags on files
find . -regex ".*\.\(p[lm]\|ksh\|bash\|ps1\|sh\|rcv|pls\|sql\)" -exec sed -i \
    -e "s/#RELEASE_VERSION/$ZIP_PRODUCT_NAME $TAG/g" \
    {} \;

Md5Sum "exe|ps1|win|dll|docx|odt"
