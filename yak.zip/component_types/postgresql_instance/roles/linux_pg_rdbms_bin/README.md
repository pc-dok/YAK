pg_rdbms_bin
=====================

Role to install PostgreSQL from source code.

Role Variables (fixed)
----------------------

n/a

Example 
-------
### Playbook

    ---
    - hosts: pg
      vars:
        # Directories structure
        pv_postgres_base: "/u01/app/postgres" # for binaries
        # Postgres version
        pv_postgres_major_version: 13
        pv_postgres_minor_version: 2
        pv_postgres_version: "{{ pv_postgres_major_version }}.{{ pv_postgres_minor_version }}"


        # Artifacts - default settings (software repo. resides on Ansible control node)
        pv_artifacts_repo:
          provider: ansible_control_node
          # remote_src = false when Artifacts available on control-node
          remote_src: false
          path: "{{ gv_appliance_home }}"


        # Postgres location
        pv_postgres_home: "{{ pv_postgres_base }}/product/{{ pv_postgres_major_version }}/db_{{pv_postgres_minor_version }}"
        pv_postgres_home_name: "pg{{ pv_postgres_version }}"

        pv_postgres_sfw: { archive: "rdbms/postgresql/postgresql-13.2.tar.bz2" }

      roles:
        - linux_pg_rdbms_bin
        

### Command line
    # ansible-playbook roles/linux_pg_rdbms_bin/tests/test.yml


Notes
-------
n/a
