linux_pg_rdbms_os_tools
=====================

Role to install useful troubleshooting tools (strace, perf, nslookup, dig, fuser, htop).

Role Variables (fixed)
----------------------

n/a

Platforms 
-------
- Red Hat based distributions (RHEL 8, Rocky Linux 8, AlmaLinux 8)

Example 
-------
### Playbook

    - name: Install OS tools
      hosts: pg
      gather_facts: true
      
      roles:
        - linux_g_rdbms_os_tools

        

### Command line
    # ansible-playbook roles/linux_pg_rdbms_os_tools/tests/test.yml


Notes
-------
n/a
