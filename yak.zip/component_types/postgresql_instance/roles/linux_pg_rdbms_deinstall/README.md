linux_pg_rdbms_deinstall
=========

Role to de-install PostgreSQL binaries.

Role Variables
--------------

n/a

Example
-------
### Playbook

    - name: Decommission PostgreSQL Home 13.2
      hosts: all
      gather_facts: false
      vars:

        - pv_postgres_base: "{{ hostvars[target].ofa.postgres_base }}"
        - pv_postgres_home: "{{ pv_postgres_base }}/product/13/db_2"

      roles:
        - linux_pg_rdbms_deinstall

### Command line
    # ansible-playbook roles/linux_pg_rdbms_deinstall/tests/tests.yml

Notes
-------

n/a