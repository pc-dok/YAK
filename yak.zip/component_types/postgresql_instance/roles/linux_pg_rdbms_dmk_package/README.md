linux_pg_rdbms_dmk_package
=====================

Role to install DMK for PostgreSQL.

Role Variables (fixed)
----------------------

n/a

Example 
-------
### Playbook

    - hosts: dev
      vars:
        # Directories structure
        pv_postgres_base: "/u01/app/postgres" # for binaries


        # Artifacts - default settings (software repo. resides on Ansible control node)
        pv_artifacts_repo:
          provider: ansible_control_node
          # remote_src = false when Artifacts available on control-node
          remote_src: false
          path: "{{ gv_appliance_home }}"

        # DMK
        pv_postgres_dmk_install_dir: "{{ pv_postgres_base }}/local"
        pv_dmk_package: "postgresql/dmk/PostgreSQL-DMK-21-05.4.zip"

        # Postgres version
        pv_postgres_major_version: 13
        pv_postgres_minor_version: 2
        pv_postgres_version: "{{ pv_postgres_major_version }}.{{ pv_postgres_minor_version }}"

        # Postgres location
        pv_postgres_home: "{{ pv_postgres_base }}/product/{{ pv_postgres_major_version }}/db_{{pv_postgres_minor_version }}"
        pv_postgres_home_name: "pg{{ pv_postgres_version }}"

      roles:
        - linux_pg_rdbms_dmk_package
        

### Command line
    # ansible-playbook roles/linux_pg_rdbms_dmk_package/tests/test.yml


Notes
-------
n/a
