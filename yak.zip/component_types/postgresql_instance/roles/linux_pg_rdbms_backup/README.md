pg_rdbms_pgbackrest
=====================

Role to install pgBackRest, configure it, create the stanza and configure the backups into the crontab.

Role Variables (fixed)
----------------------

| Var                                       | Description                                 | Default value |
| ----------------------------------------  | ------------------------------------------  | ------------- |
| rv_pg_rdbms_pgbackrest_cluster_list_fact  | Stores dynamic list of Postgres clusters    | empty         |


Example 
-------
### Playbook

    ---
    - hosts: dev
      vars:
        # Directories structure
        pv_postgres_base: "/u01/app/postgres" # for binaries
        pv_postgres_data: "/u02/pgdata"       # for PostgreSQL data
        pv_postgres_arch: "/u90/pgdata"       # for PostgreSQL archived wal

        # Postgres version
        pv_postgres_major_version: 13
        pv_postgres_minor_version: 2

        # Postgres location
        pv_postgres_home: "{{ pv_postgres_base }}/product/{{ pv_postgres_major_version }}/db_{{pv_postgres_minor_version }}"

        # DMK
        pv_postgres_dmk_install_dir: "{{ pv_postgres_base }}/local"

        # Cluster parameters
        pv_pg_instance_details:
          name: "PG01"
          port: "5432"

        # Artifacts - default settings (software repo. resides on Ansible control node)
        pv_artifacts_repo:
          provider: ansible_control_node
          # remote_src = false when Artifacts available on control-node
          remote_src: false
          path: "{{ gv_appliance_home }}"

        # pgBackRest
        pv_pgbackrest_version: "2.35"
        pv_pgbackrest_home: "{{ pv_postgres_base }}/product/pgbackrest-{{ pv_pgbackrest_version }}"
        pv_pgbackrest_home_current: "{{ pv_postgres_base }}/product/pgbackrest-current" # for archive_command parameter
        pv_pgbackrest_sfw: { archive: "rdbms/postgresql/pgbackrest-release-{{ pv_pgbackrest_version }}.tar.gz" }
        pv_pgbackrest_log_dir: "{{ pv_postgres_dmk_install_dir}}/dmk/log "
        pv_pgbackrest_backup_path: "{{ pv_postgres_arch }}"
        pv_pgbackrest_backup_conf:
          retention_full: 2
          retention_diff: 6
          schedules:
            full: { job_desc: "pgBackRest - Weekly full backup"       , type: "full", minute: 00, hour: 22, mday: "*", month: "*", weekday: 0 }
            diff: { job_desc: "pgBackRest - Daily differential backup", type: "diff", minute: 00, hour: 22, mday: "*", month: "*", weekday: "1-6" }

        # pg_dumpall
        pv_postgres_pgdumpall_path: "{{ pv_postgres_arch }}/pg_dump"
        pv_postgres_pgdumpall_conf:
          schedules:
            dump: { job_desc: "pg_dumpall - Daily dump of all databases", minute: 00, hour: 19, mday: "*", month: "*", weekday: "*" }

      roles:
        - pg_rdbms_backup

            

    ### Command line
        # ansible-playbook roles/postgres/pg_rdbms_backup/tests/test.yml


Notes
-------
n/a
