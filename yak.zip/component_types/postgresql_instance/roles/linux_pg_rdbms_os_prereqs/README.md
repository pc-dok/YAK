linux_pg_rdbms_os_prereqs
=====================

Role to install OS prerequisites for PostgreSQL database :
- Directory structure
- User
- Packages
- Tuning profile

Role Variables (fixed)
----------------------

n/a

Platforms 
-------
- Red Hat based distributions (RHEL 8, Rocky Linux 8, AlmaLinux 8)
- Suse based distributions (SLES 15)

Example 
-------
### Playbook

    - name: Install OS prerequisites
      hosts: pg
      gather_facts: true
      vars:

        # Directories structure
        pv_postgres_base: "/u01/app/postgres" # for PostgreSQL binaries
        pv_postgres_data: "/u02/pgdata"       # for PostgreSQL data
        pv_postgres_arch: "/u90/pgdata"       # for PostgreSQL archived wal

      roles:
        - linux_pg_rdbms_os_prereqs

        

### Command line
    # ansible-playbook playbooks/linux_pg_rdbms_os_prereqs/tests/test.yml


Notes
-------
n/a
