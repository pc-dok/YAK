pg_rdbms_create_cluster
========================

Role to create a new PostgreSQL cluster (initdb).

Role Variables (fixed)
----------------------

n/a

Example 
-------
### Playbook

    - name: Create Postgres cluster
      hosts: pg
      gather_facts: true
      vars:    

        # Directories structure
        pv_postgres_base: "/u01/app/postgres" # for binaries
        pv_postgres_data: "/u02/pgdata"       # for PostgreSQL data
        pv_postgres_arch: "/u90/pgdata"       # for PostgreSQL archived wal

        # Postgres version
        pv_postgres_major_version: 13
        pv_postgres_minor_version: 2
        pv_postgres_version: "{{ pv_postgres_major_version }}.{{ pv_postgres_minor_version }}"

        # Postgres location
        pv_postgres_home: "{{ pv_postgres_base }}/product/{{ pv_postgres_major_version }}/db_{{pv_postgres_minor_version }}"
        pv_postgres_home_name: "pg{{ pv_postgres_version }}"
 
        # Cluster parameters
        pv_pg_instance_details:
          name: "PG01"
          port: "5432"
          log_timezone: "'Europe/Zurich'"
          shared_buffer: "512MB" # 25% of the available memory
          work_mem: "128MB"
          maintenance_work_mem: "64MB"
        pv_pg_instance_data: "{{ pv_postgres_data }}/{{ pv_postgres_major_version }}/PG01

      roles:
        - pg_rdbms_create_cluster

        

### Command line
    # ansible-playbook roles/postgres/pg_rdbms_create_cluster/tests/test.yml


Notes
-------
n/a
