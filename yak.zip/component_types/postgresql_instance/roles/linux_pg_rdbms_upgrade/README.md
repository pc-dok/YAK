pg_rdbms_upgrade
=====================

Role to perform a minor of a major upgrade of a PostgreSQL cluster.

Example 
-------
### Playbook

    - name: Upgrade Postgres cluster
      hosts: pg
      gather_facts: true

      vars:

        # Cluster to upgrade
        pv_postgres_cluster_name: PG1


        # Directories structure
        pv_postgres_base: "/u01/app/postgres" # for binaries
        pv_postgres_data: "/u02/pgdata"       # for PostgreSQL data


        # Target Postgres version
        pv_postgres_target_major_version: 13
        pv_postgres_target_minor_version: 3
        pv_postgres_target_version: "{{ pv_postgres_target_major_version }}.{{ pv_postgres_target_minor_version }}"


        # Target Postgres location
        pv_postgres_target_home: "{{ pv_postgres_base }}/product/{{ pv_postgres_target_major_version }}/db_{{ pv_postgres_target_minor_version }}"
        pv_postgres_target_home_name: "pg{{ pv_postgres_target_major_version }}"
        pv_postgres_home: "{{ pv_postgres_target_home }}" # Required by role pg_rdbms_install


        # Target cluster parameters
        pv_postgres_target_cluster_name: "PG1"
        pv_postgres_target_cluster_port: "5432"
        pv_postgres_target_cluster_data: "{{ pv_postgres_data }}/{{ pv_postgres_target_major_version }}/{{ pv_postgres_target_cluster_name }}"
        pv_postgres_target_cluster_log_timezone: "'Europe/Zurich'"
        pv_postgres_target_cluster_shared_buffer: "512MB" # 25% of the available memory
        pv_postgres_target_cluster_work_mem: "128MB"
        pv_postgres_target_cluster_maintenance_work_mem: "64MB"

        
      roles:
        - pg_rdbms_upgrade

        

### Command line
    # ansible-playbook playbooks/pg_rdbms_upgrade.yml


Notes
-------
The role *pg_rdbms_create_cluster* must be available to 
- Initialize the new cluster before a major upgrade
- Update the systemd service file after a minor upgrade 
