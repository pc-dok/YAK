## PostgreSQL database instance definition

All dynamic component variables which are subject to changes on deployment basis are consolidated within a single configuration _variables.yml_ files part of the YaK  Inventory configuration.

```
~/yak/configuration/components/<my_component>/variables.yml
```

This table describes all the dynamic component variables.

| Group 	| Name 	| Purpose 	| Example 	|
|---	|---	|---	|---	|
| general 	|  	|  	|  	|
|  	| component_type 	| Type of the component and sub-component to deploy 	| postgresql_instance/standalone 	|
|  	| yak_manifest_postgresql_host 	| Host of the YaK Inventory on which the component will be deployed 	| aws_test/srv-debian-pg 	|
|  	| version 	| Version of PostgreSQL to deploy   | 14.8 	|
| instance_details 	|  	|  	|  	|
|  	| name 	| Name of the instance 	| PG01 	|
|  	| port 	| TCP/IP port on which the PostgreSQL instance is to listen for connections from client applications 	| 1521 	|
|  	| log_timezone 	| Time zone used for timestamps written in the server log 	| Europe/Zurich 	|
| instance_backup_pgbackrest 	|  	|  	|  	|
|  	| retention_full 	| Number of full backups to keep 	| 5 	|
|  	| retention_diff 	| Number of differential backups to keep 	| 10 	|
|  	| schedules 	| Structure of the crontab entries for the backups <ul> <li>job_desc  : comment above the entry</li> <li>type      : type of backup (full or diff)</li> <li>minute    : minute at which the backup will start</li> <li>hour      : hour at which the backup will start <li>mday      : day of the month at which the backup will start</li> <li>month     : month at which the backup will start</li> <li>weekday   : day of the week at which the backup will start</li> </ul> 	| full: { job_desc:  "pgBackRest - Weekly full backup"        , type:  "full" , minute: 00, hour: 22, mday:  "*" , month:  "*" , weekday: 0 } <br> diff: { job_desc:   "pgBackRest - Daily differential backup" , type:  "diff" , minute: 00, hour: 22, mday:  "*" , month:  "*" , weekday:  "1-6"  } 	|
| instance_backup_dumps 	|  	|  	|  	|
|  	| retention_dumps 	| Number of dumps to keep 	|  	|
|  	| schedules 	| Structure of the crontab entries for pg_dumpall <ul> <li>job_desc  : comment above the entry</li> <li>minute    : minute at which the dump will start</li> <li>hour      : hour at which the dump will start <li>mday      : day of the month at which the dump will start</li> <li>month     : month at which the dump will start</li> <li>weekday   : day of the week at which the dump will start</li> </ul> 	| dump: { job_desc:  "dmk-pg-dump - Daily dump of all databases" , minute: 00, hour: 19, mday:  "*" , month:  "*" , weekday:  "*"  } 	|
| instance_upgrade_details 	|  	|  	|  	|
|  	| target_major_release 	| Major version of the new upgraded instance 	| 15 	|
|  	| target_minor_release 	| Minor version of the new upgraded instance 	| 3 	|
