[postgresql_instance 1.1.3]
  [Enhancements]
  - Support of PostgreSQL 13.11, 14.8, 15.3
  - Support of DMK 23-03
  - Automatic upgrade of the pgBackRest stanza of the new cluster after a major upgrade
  - Use ICU local-provider starting with version 15
  - Perform upgrade from version <=14 to version >= 15 with pg_dump (due to local-provider change in version 15)
  - Open instance port in the local firewall (firewalld or ufw depending on the OS distribution)
  - Set random_page_cost to 1.1
  - Set effective_io_concurrency to 100
  - Set default_toast_compression to lz4 starting with version 14
  - Set the huge pages configuration in tuned.conf file
  - Remove the source files after the installation
  - Use scram-sha-256 authentication in pg_hba.conf
  - Delete the old cluster major version directory (only if empty) and update the mandatory dummy entry in pgtab after an upgrade
  - Support of RHEL 9

  [Fixes]
  - Version mismatch after minor upgrade
  - Major upgrade issues
  - 