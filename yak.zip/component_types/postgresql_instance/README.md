# YaK PostgreSQL instance management

[[_TOC_]]

## High-level postgresql_instance component architecture


### Directory structure

```
yak/component_types/postgresql_instance/
├── README.md   
├── artifacts_requirements.yml  - Version and path of artifacts files                  
├── build.sh                    - GitLab CI/CD pipeline triggered script
├── component_sample            - PostgreSQL database instance sample
├── docs                        - PostgreSQL database instance documentation
├── manifest.yml                - Playbook execution metadata 
├── playbooks                   - Ansible playbooks for postgresql_instance
├── roles                       - Ansible roles for postgresql_instance  
├── variables                   - Default variables for postgresql_instance
```
## HowTo's

### Configure the Artifacts provider
All PostgreSQL software sources, utilities, scripts, aso... part of the deployment process are managed through a dedicated [Ansible role](https://gitlab.com/yak4all/yak/-/blob/main/collections/ansible_collections/yak/core/roles/artifacts/README.md).

The Artifacts provider must be defined into the _variables.yml_ file of the infrastructure.

Example using an AWS S3 bucket as Artifacts provider :
```bash
cat ~/yak/configuration/infrastructure/aws_test/variables.yml
...
...
artifacts:
  provider: aws_s3
  variables:  
    bucket_name: "dbi-services-yak-artifacts"
...
...
```

Into the Artifacts provider bucket, the directory structure must be as follow :

```bash
── rdbms
    └── postgresql
        ├── dmk
        │   └── PostgreSQL-DMK-X.Y.Z.zip
        ├── pgbackrest-release-X.Y.tar.gz
        ├── postgresql-X.Y.tar.bz2

```
Those files have to be uploaded by or with dbi services.

### Prepare a PostgreSQL component

**Requirement** : the target server must be created and started before the deployment of the postgresql_instance component.

1. Create a new directory under _~/yak/configuration/components/_ to store your component configuration.
```
mkdir ~/yak/configuration/components/<my_component>
```

2. Copy the file _component_sample/variables.yml_ into the YaK components folder

```
cp ~/yak/component_types/postgresql_instance/component_sample/PG01/variables.yml \
~/yak/configuration/components/<my_component>
```

Example :

```
mkdir ~/yak/configuration/components/PG01_aws

cp ~/yak/component_types/postgresql_instance/component_sample/PG01/variables.yml \
~/yak/configuration/components/PG01_aws
```

2. Review and adapt the PostgreSQL instance parameters :

```
vi ~/yak/configuration/components/<my_component>/variables.yml
```

Refer to the file [docs/database_instance_definition.md](https://gitlab.com/dbiservices/yak/yak_components/postgresql_instance/-/blob/main/docs/postgresql_database_instance_definition.md) for details about configuration of instance specific settings.


### Deploy a PostgreSQL component

1. Set the environment variable YAK_CORE_COMPONENT to <my_component>

Example :

```bash
export YAK_CORE_COMPONENT=PG01_aws

# or use the alias "sc" (set component)
sc PG01_aws
```

2. Deploy the PostgreSQL component

```bash
ansible-playbook \
~/yak/component_types/postgresql_instance/playbooks/linux/deploy.yml
```

### Upgrade a PostgreSQL component

1. Set the environment variable YAK_CORE_COMPONENT to <my_component>

2. Upgrade the PostgreSQL component

```bash
ansible-playbook \
~/yak/component_types/postgresql_instance/playbooks/linux/upgrade.yml
```

### Remove an unused PostgreSQL binary

1. Set the environment variable YAK_CORE_COMPONENT to <my_component>
2. Remove the PostgreSQL binary

**Version 13.2**

```bash
ansible-playbook \
~/yak/component_types/postgresql_instance/playbooks/linux/decommission_postgresql_home_13_2.yml
```

**Version 14.3**

```bash
ansible-playbook \
~/yak/component_types/postgresql_instance/playbooks/linux/decommission_postgresql_home_14_2.yml
```
If an binary is currently used by a PostgreSQL instance, it will not be removed.
