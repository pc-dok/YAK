# yak.core

The yak.core is a collection of inventory plugins, modules and roles used by the YaK core project.

## Inventory plugins

[Go to page](./plugins/README.md)
